<?php if (isset($component)) { $__componentOriginaldc5bb066dd29f06f61029da7c7c61b14 = $component; } ?>
<?php $component = App\View\Components\GerenciaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('gerencia-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GerenciaLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container flex flex-col justify-center items-center">
        <div>
            <span class="text-xl font-bold uppercase mt-10">Bienvenido Departamento Gerencia</span>
        </div>
        <div class="bg-white rounded-md p-6 mt-10">
            <div class="mt-10">
                <span class="font-bold">EXPORTAR COBERTURAS GENERALES POR TIPO DE SECTOR</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('gerencia.asignacion-exportar.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-green-500 text-white">Exportar Cobertura General</button>
                    </div>
                </form>
            </div>
            <div class="mt-10">
                <span class=" font-bold">EXPORTAR SEGUIMIENTOS/SUPERVISION POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('gerencia.exportar-seguimiento.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-blue-500 text-white">Exportar Seguimiento Individual</button>
                    </div>
                </form>
            </div>
            <div class="mt-10">
                <span class="font-bold">EXPORTAR SEGUIMIENTOS/SUPERVISION TOTAL POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('gerencia.exportar-seguimiento-total.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-sky-500 text-white">Exportar Seguimiento General</button>
                    </div>
                </form>
            </div>
            <div class="mt-10">
                <span class="font-bold">EXPORTAR SEGUIMIENTOS TOTAL 1 A 1 POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('gerencia.exportar-seguimientos-1-1.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-rose-500 text-white">Exportar Seguimientos 1-1</button>
                    </div>
                </form>
            </div>
            <div class="mt-10">
                <span class="font-bold">EXPORTAR SUPERVISIONES TOTAL 1 A 1 POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('gerencia.exportar-supervisiones-1-1.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-amber-500 text-white">Exportar Supervisones 1-1</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc5bb066dd29f06f61029da7c7c61b14)): ?>
<?php $component = $__componentOriginaldc5bb066dd29f06f61029da7c7c61b14; ?>
<?php unset($__componentOriginaldc5bb066dd29f06f61029da7c7c61b14); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\gerencia\dashboard.blade.php ENDPATH**/ ?>