<div>
    <!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\encuestador-layout.blade.php ENDPATH**/ ?>