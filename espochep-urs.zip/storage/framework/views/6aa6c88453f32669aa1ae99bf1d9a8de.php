<?php if (isset($component)) { $__componentOriginale6c8c1a92b470a09ffc5f92101d99513 = $component; } ?>
<?php $component = App\View\Components\CampoLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('campo-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CampoLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container  flex flex-col justify-center items-center h-[90vh]">
        <div class="">
            <span class="text-xl font-bold uppercase">Bienvenido Supervisor de Campo</span>
        </div>
        <div class="bg-white rounded-md p-6 mt-10">
            <div>
                <span class=" font-bold">EXPORTAR COBERTURA POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('campo.exportar-cobertura.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-blue-500 text-white">Exportar Coberturas</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="bg-white rounded-md p-6 mt-10">
            <div>
                <span class=" font-bold">EXPORTAR COBERTURA CONSOLIDADA POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('campo.exportar-coberturas-consolidadas.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-green-500 text-white">Exportar Cobertura del Equipo</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="bg-white rounded-md p-6 mt-10">
            <div>
                <span class=" font-bold">EXPORTAR SEGUIMIENTOS Y SUPERVISIONES POR FASE</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('campo.exportar-seguimientos.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-blue-500 text-white">Exportar Seguimientos/Supervisiones</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6c8c1a92b470a09ffc5f92101d99513)): ?>
<?php $component = $__componentOriginale6c8c1a92b470a09ffc5f92101d99513; ?>
<?php unset($__componentOriginale6c8c1a92b470a09ffc5f92101d99513); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\campo\dashboard.blade.php ENDPATH**/ ?>