<div>
    <!-- Act only according to that maxim whereby you can, at the same time, will that it should become a universal law. - Immanuel Kant -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\socializador-layout.blade.php ENDPATH**/ ?>