<div class="max-w-7xl mx-auto p-6 bg-white rounded-md mt-4">
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div>
        <h2 class="text-lg font-semibold text-center mt-3 mb-5">BUSQUEDA DE EQUIPOS PARA VERIFICAR CARGA POR DIA</h2>
        <div class="flex justify-center">
            <div>
                <input class="rounded-md border border-gray-300 text-sm" wire:model="equipmentNumber"
                    type="text" placeholder="Número de equipo C4G01">
                <div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'equipmentNumber']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'equipmentNumber']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </div>
            <div>
                <input class="rounded-md border border-gray-300 text-sm ml-3" wire:model="fecha" type="date"
                    placeholder="Fecha de busqueda">
                <div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'fecha']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'fecha']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </div>
            <button class="bg-gray-800 text-white rounded-md px-3 py-2 text-sm ml-3"
                wire:click="performSearch">Buscar</button>
        </div>

        <?php if(!empty($teamMembers)): ?>
            <div class="rounded-md border relative border-sky-500 bg-white overflow-x-hidden mt-6 shadow-md">
                <table class="w-full table-auto divide-y divide-gray-200 overflow-hidden rounded-md">
                    <thead class="bg-sky-500 text-white">
                        <tr class="text-xs">
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                                Equipo/Cargo</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                                Nombres</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Efect.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Rech.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                INC</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                NEC</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Temp.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Deso.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Dest.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Const.</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-xs font-medium uppercase tracking-wider">
                                Total</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-xs hover:text-white hover:bg-sky-400">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-center font-medium">
                                        <?php echo e($member->equipment->name); ?>

                                    </div>
                                    <div class="text-center">
                                        <?php switch($member->role):
                                            case ('admin'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    Administrador
                                                </span>
                                            <?php break; ?>

                                            <?php case ('gerente'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                    Gerente
                                                </span>
                                            <?php break; ?>

                                            <?php case ('calidad'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    Supervisor Calidad
                                                </span>
                                            <?php break; ?>

                                            <?php case ('campo'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                    Supervisor Campo
                                                </span>
                                            <?php break; ?>

                                            <?php case ('encuestador'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-sky-100 text-sky-800">
                                                    Encuestador
                                                </span>
                                            <?php break; ?>

                                            <?php case ('socializador'): ?>
                                                <span
                                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                    Socializador
                                                </span>
                                            <?php break; ?>

                                            <?php default: ?>
                                        <?php endswitch; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($member->name); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <div
                                        class="w-8 h-8 rounded-full bg-green-500 text-white font-medium flex justify-center items-center">
                                        <?php echo e($member->total_efectivas ? $member->total_efectivas : '--'); ?>

                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_rechazo ? $member->total_rechazo : '--'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_informante ? $member->total_informante : '--'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_nadie_en_casa ? $member->total_nadie_en_casa : '--'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_temporal ? $member->total_temporal : '--'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_desocupada ? $member->total_desocupada : '--'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_destruida ? $member->total_destruida : '--'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php echo e($member->total_construccion ? $member->total_construccion : '--'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <div
                                        class="w-8 h-8 rounded-full bg-sky-500 text-white font-medium flex justify-center items-center">
                                        <?php echo e($member->total_efectivas + $member->total_rechazo + $member->total_informante + $member->total_nadie_en_casa); ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\livewire\calidad\equipos-cobertura.blade.php ENDPATH**/ ?>