<div class="max-w-6xl mx-auto rounded-md bg-white p-6 mt-6">
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center space-x-6">
        <input class="rounded-md border border-gray-300 text-sm" wire:model="teamName" type="text"
            placeholder="C4G01">
        <button class="text-sm bg-gray-800 text-white rounded-md px-3" wire:click="searchMembers">Buscar</button>
    </div>

    <?php if(!empty($users)): ?>
        <div class="py-6">
            <hr>
        </div>
        <div class="max-w-2xl mx-auto">
            <div>
                <h2 class="pb-4 font-semibold uppercase text-center">Usuarios del Equipo</h2>
                <ul class="space-y-3">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <?php switch($user->status):
                                case ('activo'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Activo
                                    </span>
                                <?php break; ?>

                                <?php case ('inactivo'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                        Inactivo
                                    </span>
                                <?php break; ?>

                                <?php default: ?>
                            <?php endswitch; ?>
                            - <span class="text-sm"> <?php echo e($user->name); ?> </span> 
                            - <span class="text-sm"> <?php echo e($user->phone ? $user->phone : 'Sin telefono'); ?> </span> -
                            <?php switch($user->role):
                                case ('admin'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Administrador
                                    </span>
                                <?php break; ?>

                                <?php case ('gerente'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                        Gerente
                                    </span>
                                <?php break; ?>

                                <?php case ('calidad'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Supervisor de Calidad
                                    </span>
                                <?php break; ?>

                                <?php case ('campo'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                        Supervisor de Campo
                                    </span>
                                <?php break; ?>

                                <?php case ('encuestador'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-sky-100 text-skbg-sky-800">
                                        Encuestador
                                    </span>
                                <?php break; ?>

                                <?php case ('socializador'): ?>
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                        Socializador
                                    </span>
                                <?php break; ?>

                                <?php default: ?>
                            <?php endswitch; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    <div class="w-full mx-auto mt-6">
        <?php if($errorMessage): ?>
            <div class="w-56 mx-auto">
                <p class="bg-red-500 text-white rounded-md px-3 py-2 text-sm"><?php echo e($errorMessage); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\livewire\verificar-integrantes.blade.php ENDPATH**/ ?>