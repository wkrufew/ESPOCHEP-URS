<div>
    <!-- Life is available only in the present moment. - Thich Nhat Hanh -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\provincial-layout.blade.php ENDPATH**/ ?>