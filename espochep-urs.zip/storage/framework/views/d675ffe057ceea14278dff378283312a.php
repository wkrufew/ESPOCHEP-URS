<div class="max-w-6xl mx-auto rounded-md bg-white p-6 mt-6">
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center space-x-6">
        <input class="rounded-md border border-gray-300 text-sm" wire:model="searchQuery" type="text"
            placeholder="Cédula o Nombre">
        <button class="text-sm bg-gray-800 text-white rounded-md px-3" wire:click="searchUser">Buscar</button>
    </div>

    <?php if($user): ?>
        <div class="py-6">
            <hr>
        </div>
        <div class="max-w-lg mx-auto">
            <p class="text-sm"><span class="font-semibold">Nombre: </span> <?php echo e($user->name); ?></p>
            <p><span class="font-semibold text-sm">Equipo: </span>
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-sky-100 text-sky-800">
                    <?php echo e(optional($user->equipment)->name ? optional($user->equipment)->name : 'Sin asignar'); ?>

                </span>
            </p>
            <p>
                <span class="font-semibold text-sm">Estado: </span>
                <?php switch($user->status):
                    case ('activo'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Activo
                        </span>
                    <?php break; ?>

                    <?php case ('inactivo'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                            Inactivo
                        </span>
                    <?php break; ?>

                    <?php default: ?>
                <?php endswitch; ?>
            </p>
            <p>
                <span class="font-semibold text-sm">Cargo: </span>
                <?php switch($user->role):
                    case ('admin'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Administrador
                        </span>
                    <?php break; ?>

                    <?php case ('gerente'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            Gerente
                        </span>
                    <?php break; ?>

                    <?php case ('calidad'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Supervisor de Calidad
                        </span>
                    <?php break; ?>

                    <?php case ('campo'): ?>
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            Supervisor de Campo
                        </span>
                    <?php break; ?>

                    <?php case ('encuestador'): ?>
                        <span
                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-sky-100 text-skbg-sky-800">
                            Encuestador
                        </span>
                    <?php break; ?>

                    <?php case ('socializador'): ?>
                        <span
                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                            Socializador
                        </span>
                    <?php break; ?>
                    <?php case ('provincial'): ?>
                        <span
                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-rose-100 text-rose-800">
                            Coordinador Provincial
                        </span>
                    <?php break; ?>

                    <?php default: ?>
                <?php endswitch; ?>
            </p>
        </div>
    <?php endif; ?>

    <div class="w-full mx-auto mt-6">
        <?php if($errorMessage): ?>
        <div class="w-56 mx-auto">
            <p class="bg-red-500 text-white rounded-md px-3 py-2 text-sm"><?php echo e($errorMessage); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\livewire\verificar-equipo.blade.php ENDPATH**/ ?>