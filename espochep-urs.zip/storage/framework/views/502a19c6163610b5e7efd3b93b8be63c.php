<div>
    <!-- Because you are alive, everything is possible. - Thich Nhat Hanh -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\campo-layout.blade.php ENDPATH**/ ?>