<div class="loader" id="loader-6">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <div class="flex justify-center items-center absolute mt-32">
        <p class="text-white text-sm font-medium text-center relative"><?php echo e($message  ? : 'Cargando vista...'); ?></p>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\loading.blade.php ENDPATH**/ ?>