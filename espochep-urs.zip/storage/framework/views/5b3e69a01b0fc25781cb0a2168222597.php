<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\admin-layout.blade.php ENDPATH**/ ?>