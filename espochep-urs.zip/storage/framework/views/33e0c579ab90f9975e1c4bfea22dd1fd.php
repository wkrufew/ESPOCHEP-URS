<div class="max-w-6xl mx-auto p-6">
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div>
        
        <div>
            <div class="bg-white p-4 rounded-md text-sm flex justify-between flex-wrap">
                <div>
                    <span class="font-semibold">Nombre: </span> <?php echo e(auth()->user()->name); ?>

                </div>
                <div class="capitalize">
                    <span class="font-semibold">Rol: </span> <?php echo e(auth()->user()->role); ?>

                </div>
                <div>
                    <span class="font-semibold">Equipo: </span> 
                    <?php if(!empty(auth()->user()->equipment->name)): ?>
                        <?php echo e(auth()->user()->equipment->name); ?>

                    <?php else: ?>
                        Sin equipo
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="flex flex-col md:flex-row justify-center md:space-x-6 mt-6">
            <div>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Tipo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Tipo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <select class="w-full border border-gray-200 rounded-md shadow-sm" wire:model.live="tipo">
                    <option value="">Seleccione un tipo</option>
                    <option value="Seguimiento">Seguimiento</option>
                    <option value="Supervision">Supervision</option>
                </select>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'tipo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'tipo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
            <div class="mb-4 relative mx-auto  md:w-56 mt-4 md:mt-0">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Certificado']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Certificado']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <div class="flex justify-center">
                    <input class="rounded-md  border border-gray-300 w-full mx-auto md:w-56" wire:model.live.debounce.500ms="search" type="text"
                        placeholder="Buscar certificado">
                    <?php if($certificados && $certificados->count()): ?>
                        <div class="absolute w-56 mt-1 hidden z-50 bg-white p-1 rounded-md border border-gray-100 shadow-lg"
                            :class="{ 'hidden': !$wire.open }" x-on:click.away="$wire.open = false">
                            <ul>
                                <?php $__currentLoopData = $certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li x-on:click.away="$wire.open = false"
                                        class="hover:bg-green-200 px-1 py-0.5 rounded-md cursor-pointer"
                                        wire:click="seleccionarCertificado(<?php echo e($certificado->id); ?>)">
                                        <?php echo e($certificado->code); ?> - <?php echo e($certificado->equipment->name); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <div class="w-full mt-2">
                    <div class="flex justify-center">
                        <p><span
                                class="<?php echo e($selectedCertificado ? 'bg-green-500' : 'bg-gray-500'); ?> text-white px-2 py-1 rounded-full text-sm">
                                <?php echo e($selectedCertificado ? $selectedCertificado->code : 'Elegir un Certificado'); ?></span>
                        </p>
                    </div>
                    <?php $__errorArgs = ['selectedCertificado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        
        <div class="mt-6 bg-white p-6 rounded-md">
            <h2 class="text-center font-semibold uppercase">Datos de la Encuesta</h2>
            <?php if($selectedCertificado && $datos_encuestador): ?>
                <div class="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4 text-sm">
                    <div>
                        <span class="font-semibold">Fecha Encuesta:
                        </span><?php echo e(\Carbon\Carbon::parse($datos_encuestador->fecha_encuesta)->format('d/m/Y')); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Encuestador: </span> <?php echo e($datos_encuestador->user->name); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Cedula: </span> <?php echo e($datos_encuestador->user->cedula); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Telefono: </span> <?php echo e($datos_encuestador->user->phone); ?>

                    </div>
                </div>
                <div class="mt-4 text-sm">
                    <span class="font-semibold">Observacion: </span> <?php echo e($datos_encuestador->observacion); ?>

                </div>
                <div class="flex justify-evenly text-sm">
                    <div>
                        <?php if($datos_encuestador->efectivas): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->efectivas ? 'Efectiva' : ''); ?>

                        <?php elseif($datos_encuestador->temporal): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->temporal ? 'Temporal' : ''); ?>

                        <?php elseif($datos_encuestador->nadie_en_casa): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->nadie_en_casa ? 'Nadie en Casa' : ''); ?>

                        <?php elseif($datos_encuestador->construccion): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->construccion ? 'Construccion' : ''); ?>

                        <?php elseif($datos_encuestador->destruida): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->destruida ? 'Destruida' : ''); ?>

                        <?php elseif($datos_encuestador->desocupada): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->desocupada ? 'Desocupada' : ''); ?>

                        <?php elseif($datos_encuestador->rechazo): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->rechazo ? 'Rechazo' : ''); ?>

                        <?php elseif($datos_encuestador->informante_no_calificado): ?>
                            <span class="font-semibold">Encuesta: </span>
                            <?php echo e($datos_encuestador->informante_no_calificado ? 'Informante No Calificado' : ''); ?>

                        <?php endif; ?>
                    </div>
                    <div>
                        <span class="font-semibold">Certificado: </span>
                        <?php echo e($datos_encuestador->certificado->code ? $datos_encuestador->certificado->code : ''); ?>

                    </div>
                    <div class="mb-4">
                        <span class="font-semibold">Sticker: </span>
                        <?php echo e($datos_encuestador->sticker->code ? $datos_encuestador->sticker->code : ''); ?>

                    </div>
                </div>
                
                <hr>
                <div class="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4 text-sm">
                    <div>
                        <span class="font-semibold">Planificacion: </span> <?php echo e($datos_encuestador->planning->code); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Fase: </span> <?php echo e($datos_encuestador->planning->phase->name); ?>

                    </div>
                    <div class="col-span-1 md:col-span-2">
                        <span class="font-semibold">Fecha Inicio: </span>
                        <?php echo e(\Carbon\Carbon::parse($datos_encuestador->planning->fecha_inicio)->format('d/m/Y')); ?> -
                        <?php echo e(\Carbon\Carbon::parse($datos_encuestador->planning->fecha_fin)->format('d/m/Y')); ?>

                    </div>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-6 mt-4 text-sm">
                    <div>
                        <span class="font-semibold">Provincia: </span> <?php echo e($datos_encuestador->planning->provincia); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Canton: </span> <?php echo e($datos_encuestador->planning->canton); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Parroquia: </span> <?php echo e($datos_encuestador->planning->parroquia); ?>

                    </div>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-4 text-sm">
                    <div>
                        <span class="font-semibold">DPA: </span> <?php echo e($datos_encuestador->planning->dpa); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Area Censal: </span> <?php echo e($datos_encuestador->planning->areacensal); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Codigo Manzana: </span>
                        <?php echo e($datos_encuestador->planning->codigo_manzana); ?>

                    </div>
                    <div>
                        <span class="font-semibold">Tipo Sector: </span>
                        <?php switch($datos_encuestador->planning->tipo_sector):
                            case (1): ?>
                                <span
                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    Amanzando
                                </span>
                            <?php break; ?>

                            <?php case (2): ?>
                                <span
                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                    Disperso
                                </span>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="flex justify-center items-center h-full">
                    Elegir un Certificado
                </div>
            <?php endif; ?>
        </div>
        <div class="p-3 mt-6 bg-white rounded-md shadow-md">
            <h2 class="text-sm text-center font-medium uppercase">Calificacion de Encuesta
                <?php if($datos_encuestador): ?>
                    a <?php echo e($datos_encuestador->user->name); ?>

                <?php endif; ?>
            </h2>
            <div>
                <?php if($tipo == 'Seguimiento'): ?>
                    <div class="grid grid-cols-2 md:grid-cols-7 gap-4 mt-4">
                        <div class="">
                            <h3 class="text-xs font-medium text-center">Registro Nombres?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="id1"
                                        class="cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_nombres" type="radio" name="registro_nombres"
                                            value="Si" id="id1" class="mr-2 appearance-none">
                                    </label>
                                    <label for="id4"
                                        class="cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_nombres" class=" appearance-none" type="radio"
                                        value="No" name="registro_nombres" id="id2">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_nombres']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_nombres']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Sexo?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_sexosi"
                                        class="cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_sexo" class="mr-2 appearance-none" type="radio"
                                        value="Si"name="registro_sexo" id="registro_sexosi">
                                    </label>
                                    <label for="registro_sexono"
                                        class="cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_sexo" class=" appearance-none" type="radio"
                                        value="No"name="registro_sexo" id="registro_sexono">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_sexo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_sexo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Nacimiento?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_nacimientosi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_nacimiento" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="registro_nacimiento" id="registro_nacimientosi">
                                    </label>
                                    <label for="registro_nacimientono"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_nacimiento" class=" appearance-none"
                                        value="No" type="radio" name="registro_nacimiento" id="registro_nacimientono">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_nacimiento']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_nacimiento']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Cedula?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_cedulasi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_cedula" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="registro_cedula" id="registro_cedulasi">
                                    </label>
                                    <label for="registro_cedulano"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_cedula" class=" appearance-none" type="radio"
                                        value="No" name="registro_cedula" id="registro_cedulano">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_cedula']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_cedula']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Parentesco?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_aparentesco_hogarsi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_aparentesco_hogar" class="mr-2 appearance-none"
                                           value="Si" type="radio" name="registro_aparentesco_hogar"
                                            id="registro_aparentesco_hogarsi">
                                    </label>
                                    <label for="registro_aparentesco_hogarno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_aparentesco_hogar" class=" appearance-none"
                                        value="No" type="radio" name="registro_aparentesco_hogar"
                                            id="registro_aparentesco_hogarno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_aparentesco_hogar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_aparentesco_hogar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Nucleos?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_nucleossi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_nucleos" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="registro_nucleos" id="registro_nucleossi">
                                    </label>
                                    <label for="registro_nucleosno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_nucleos" class=" appearance-none" type="radio"
                                        value="No" name="registro_nucleos" id="registro_nucleosno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_nucleos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_nucleos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Parentesco con el nucleo familiar?
                            </h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_aparentesco_nucleosi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_aparentesco_nucleo" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="registro_aparentesco_nucleo"
                                            id="registro_aparentesco_nucleosi">
                                    </label>
                                    <label for="registro_aparentesco_nucleono"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_aparentesco_nucleo" class=" appearance-none"
                                        value="No" type="radio" name="registro_aparentesco_nucleo"
                                            id="registro_aparentesco_nucleono">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_aparentesco_nucleo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_aparentesco_nucleo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php elseif($tipo == 'Supervision'): ?>
                    <div class="grid grid-cols-2 md:grid-cols-7 gap-4 mt-4">
                        <div class="">
                            <h3 class="text-xs font-medium text-center">Registro Ubicacion?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="ubicacionsi" 
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="ubicacion" type="radio" name="ubicacion"
                                        value="Si"    value="Si" id="ubicacionsi" class="mr-2 appearance-none">
                                    </label>
                                    <label for="ubicacionno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="ubicacion" class=" appearance-none" type="radio"
                                        value="No"   name="ubicacion" id="ubicacionno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'ubicacion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'ubicacion']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div class="">
                            <h3 class="text-xs font-medium text-center">Presentacion?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="presentacionsi" 
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="presentacion" type="radio" name="presentacion"
                                        value="Si"   value="activo" id="presentacionsi" class="mr-2 appearance-none">
                                    </label>
                                    <label for="presentacionno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="presentacion" class="appearance-none" type="radio"
                                        value="No"   name="presentacion" id="presentacionno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'presentacion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'presentacion']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Objetivo?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="objetivosi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="objetivo" class="mr-2 appearance-none" type="radio"
                                        value="Si" name="objetivo" id="objetivosi">
                                    </label>
                                    <label for="objetivono"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="objetivo" class="appearance-none" type="radio"
                                        value="No"   name="objetivo" id="objetivono">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'objetivo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'objetivo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Tipo de Vivienda?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="tipo_viviendasi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="tipo_vivienda" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="tipo_vivienda" id="tipo_viviendasi">
                                    </label>
                                    <label for="tipo_viviendano"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="tipo_vivienda" class="appearance-none"
                                        value="No" type="radio" name="tipo_vivienda" id="tipo_viviendano">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'tipo_vivienda']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'tipo_vivienda']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Diligencia las Preguntas?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="diligencia_preguntassi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="diligencia_preguntas" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="diligencia_preguntas" id="diligencia_preguntassi">
                                    </label>
                                    <label for="diligencia_preguntasno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="diligencia_preguntas" class="appearance-none" type="radio"
                                        value="No" name="diligencia_preguntas" id="diligencia_preguntasno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'diligencia_preguntas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'diligencia_preguntas']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Miembros del hogar?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="miembros_hogarsi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="miembros_hogar" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="miembros_hogar"
                                            id="miembros_hogarsi">
                                    </label>
                                    <label for="miembros_hogarno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="miembros_hogar" class=" appearance-none"
                                        value="No" type="radio" name="miembros_hogar"
                                            id="miembros_hogarno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'miembros_hogar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'miembros_hogar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Numero de Nucleos?</h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="numero_nucleossi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="numero_nucleos" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="numero_nucleos" id="numero_nucleossi">
                                    </label>
                                    <label for="numero_nucleosno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="numero_nucleos" class=" appearance-none" type="radio"
                                        value="No" name="numero_nucleos" id="numero_nucleosno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'numero_nucleos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'numero_nucleos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Registro Certificado?
                            </h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="registro_certificadosi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="registro_certificado" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="registro_certificado"
                                            id="registro_certificadosi">
                                    </label>
                                    <label for="registro_certificadono"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="registro_certificado" class=" appearance-none"
                                        value="No" type="radio" name="registro_certificado"
                                            id="registro_certificadono">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'registro_certificado']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'registro_certificado']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xs font-medium text-center">Forlumarios Imagenes?
                            </h3>
                            <div class="flex justify-center mt-2">
                                <div class="flex items-center justify-center">
                                    <label for="formulario_imagenessi"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">Si</span>
                                        <input wire:model="formulario_imagenes" class="mr-2 appearance-none"
                                        value="Si" type="radio" name="formulario_imagenes"
                                            id="formulario_imagenessi">
                                    </label>
                                    <label for="formulario_imagenesno"
                                        class="hover:cursor-pointer flex items-center text-xs font-medium">
                                        <span class="mr-1">No</span>
                                        <input wire:model="formulario_imagenes" class=" appearance-none"
                                        value="No"type="radio" name="formulario_imagenes"
                                            id="formulario_imagenesno">
                                    </label>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'formulario_imagenes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'formulario_imagenes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="mt-6">
            <div class="">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    Observacion
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <textarea class="w-full resize mt-1 rounded-md border border-gray-300" wire:model="observacion" name=""
                    id="" rows="2"></textarea>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'observacion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'observacion']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
        </div>
        
        <div class="mt-6 flex justify-center">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:target' => 'save','wire:click' => 'save','class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:target' => 'save','wire:click' => 'save','class' => '']); ?>
                Crear Registro
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\livewire\calidad\create-seguimiento.blade.php ENDPATH**/ ?>