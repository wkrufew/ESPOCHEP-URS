<div>
    <!-- People find pleasure in different ways. I find it in keeping my mind clear. - Marcus Aurelius -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\calidad-layout.blade.php ENDPATH**/ ?>