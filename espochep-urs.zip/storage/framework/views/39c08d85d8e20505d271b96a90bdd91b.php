<div>
    <!-- The whole future lies in uncertainty: live immediately. - Seneca -->
</div><?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\components\gerencia-layout.blade.php ENDPATH**/ ?>