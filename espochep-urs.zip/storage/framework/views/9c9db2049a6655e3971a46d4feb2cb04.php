<?php if (isset($component)) { $__componentOriginalf6ce200a180bac3eb29b308c52601a20 = $component; } ?>
<?php $component = App\View\Components\ProvincialLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('provincial-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProvincialLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div class="container flex flex-col justify-center items-center mt-10 ">
        <div>
            <span class="md:text-xl font-semibold uppercase mt-10">Bienvenido coordinador provincial</span>
        </div>
        <div class="bg-white rounded-md p-6 mt-10">
            <div>
                <span class="font-bold">EXPORTAR COBERTURAS GENERALES POR TIPO DE SECTOR</span>
            </div>
            <div class="mt-6">
                <div class="mb-6">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-red-500 text-sm">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('provincial.asignacion-exportar.index')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="w-full" for="phase">Selecciona la fase:</label>
                    <select name="phase" id="phase" class="broder border-gray-400 rounded-md">
                        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($phase->id); ?>"><?php echo e($phase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="mt-10 flex justify-center">
                        <button type="submit" class="px-3 py-2 rounded-md bg-green-500 text-white">Exportar Cobertura
                            General</button>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6ce200a180bac3eb29b308c52601a20)): ?>
<?php $component = $__componentOriginalf6ce200a180bac3eb29b308c52601a20; ?>
<?php unset($__componentOriginalf6ce200a180bac3eb29b308c52601a20); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\provincial\dashboard.blade.php ENDPATH**/ ?>