<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl mx-auto mt-4">
        <div class="flex flex-col justify-center">
            <div class="bg-white rounded-md p-4 max-w-5xl">
                <div class="text-xl font-bold uppercase text-center flex justify-center mb-10">Importar Planificaciones</div>
                <div class="my-4">
                    <?php if(isset($errors) && $errors->any()): ?>
                        <div class="bg-white rounded-md p-4 max-w-5xl mb-4">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-red-500 text-sm">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('admin.planificaciones.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="flex justify-center">
                        <input type="file" name="import_file">
                    </div>
                    <div class="mt-6 flex justify-center">
                        <button class="bg-blue-500 rounded-md text-white text-sm px-3 py-2"
                            type="submit">Importar Planificaciones</button>
                    </div>
                </form>
            </div>
        </div>
        <div>
            <div class="loader" id="loader-6">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <div class="flex justify-center items-center absolute mt-32">
                    <p class="text-[#3e3e66] text-sm font-semibold text-center relative">Enviando el formulario...</p>
                </div>
            </div>
            <script>
                window.addEventListener("load", () => {
                        const loader = document.querySelector(".loader");
                        loader.classList.add("loader--hidden");
                        loader.addEventListener("transitionend", () => {
                            document.body.removeChild(loader);
                        });
                    });
            </script>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\admin\importar.blade.php ENDPATH**/ ?>