<div>
    <div wire:loading>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => ['message' => 'Cargando datos...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Cargando datos...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div class="max-w-6xl mx-auto bg-white rounded-md p-4 mt-4">
        <h2 class="text-center py-4 font-semibold">CONSULTA DE PLANIFICACIONES ASIGNADAS</h2>
        <div class="max-w-lg mx-auto p-4 mt-4">
            <div class="flex justify-evenly">
                <div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        Fase
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <select class="border border-gray-300 rounded-md" name="" id="" wire:model="phases">
                        <option value="">Seleccione una fase</option>
                        <?php $__currentLoopData = $fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fase->id); ?>"><?php echo e($fase->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'phases']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'phases']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        Numero de Equipo
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model' => 'equipmentNumber','type' => 'text','placeholder' => 'Número de equipo Ejm. C4G01','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'equipmentNumber','type' => 'text','placeholder' => 'Número de equipo Ejm. C4G01','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'equipmentNumber']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'equipmentNumber']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <div class="p-4 flex justify-center">
            <button class="px-4 py-2 rounded-full bg-gray-800 text-white" wire:click="search">Consultar</button>
        </div>

        <div class="">
            <?php if($errorMessage): ?>
                <div class="w-96 mx-auto mt-4">
                    <p class="bg-red-500 text-white rounded-md px-3 py-2 text-sm text-center"><?php echo e($errorMessage); ?>

                    </p>
                </div>
            <?php else: ?>
                <div class="flex justify-center w-full mx-auto mt-4">
                    <div wire:loading>
                        Buscando...
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($visible): ?>
        <div class="max-w-6xl mx-auto bg-white rounded-md p-4 mt-4">
            <?php if(!empty($planifications)): ?>
                <h3 class="text-center uppercase font-semibold">Resultados</h3>
                <div class="text-sm grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    <?php $__currentLoopData = $planifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-400 shadow-md p-2 rounded-md">
                            <div class="flex justify-between">
                                <div>
                                    <p><b>Codigo: </b> <?php echo e($planification->code); ?></p>
                                </div>
                                <div>
                                    <p><b>Fase: </b> <?php echo e($planification->phase->name); ?></p>
                                </div>
                                <div>
                                    <p><b>Equipo: </b> <?php echo e($planification->equipment->name); ?></p>
                                </div>
                            </div>
                            <p><b>Provincia: </b> <?php echo e($planification->provincia); ?></p>
                            <p><b>Canton: </b> <?php echo e($planification->canton); ?></p>
                            <p><b>Parroquia: </b> <?php echo e($planification->parroquia); ?></p>
                            <p><b>Codigo de Sector/Manzana: </b> <?php echo e($planification->codigo_manzana); ?></p>
                            <p><b>Hogares Planificados: </b> <?php echo e($planification->hogares_planificados); ?></p>
                            <p><b>Fecha Intervencion: </b>
                                <?php echo e(\Carbon\Carbon::parse($planification->fecha_inicio)->format('d/m/Y')); ?> -
                                <?php echo e(\Carbon\Carbon::parse($planification->fecha_fin)->format('d/m/Y')); ?> </p>
                            <p><b>Dias de intervencion: </b> <?php echo e($planification->dias); ?></p>
                            <p><b>Tipo Sector: </b>
                                <?php switch($planification->tipo_sector):
                                    case (1): ?>
                                        <span
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                            Amanzanado
                                        </span>
                                    <?php break; ?>

                                    <?php case (2): ?>
                                        <span
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                            Disperso
                                        </span>
                                    <?php break; ?>

                                    <?php default: ?>
                                <?php endswitch; ?>
                            </p>
                            <p><b>Estado: </b>
                                <?php switch($planification->status):
                                    case (1): ?>
                                        <span
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-sky-100 text-sky-800">
                                            Abierto
                                        </span>
                                    <?php break; ?>

                                    <?php case (2): ?>
                                        <span
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                            Cerrado
                                        </span>
                                    <?php break; ?>

                                    <?php default: ?>
                                <?php endswitch; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                no se encontraron resultados
            <?php endif; ?>
        </div>
    <?php else: ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\espochep-urs\resources\views\livewire\search-plannings.blade.php ENDPATH**/ ?>