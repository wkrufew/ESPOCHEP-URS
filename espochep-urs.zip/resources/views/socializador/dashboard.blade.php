<x-socializador-layout>
    <div wire:loading>
        <x-loading message="Cargando datos..."/>
    </div>
    <div class="container">
        <div class="flex justify-center items-center h-[90vh]">
            <span class="text-xl font-bold uppercase">Bienvenido Socializador</span>
        </div>
    </div>
</x-socializador-layout>