<?php

namespace App\Exports;

use App\Models\Seguimiento;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class Supervision1Export implements FromCollection, ShouldAutoSize, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Seguimiento::where('tipo', 'Supervision')
            ->join('plannings', 'seguimientos.planning_id', '=', 'plannings.id')
            ->leftJoin('certificados', 'seguimientos.certificado_id', '=', 'certificados.id')
            ->join('users', 'seguimientos.user_id', '=', 'users.id') // Agrega la relación con users
            ->orderBy('plannings.codigo_manzana')
            ->orderBy('seguimientos.fecha_seguimiento')
            ->select([
                'seguimientos.fecha_seguimiento',
                'seguimientos.tipo',
                'seguimientos.observacion',
                'seguimientos.ubicacion',
                'seguimientos.objetivo',
                'seguimientos.tipo_vivienda',
                'seguimientos.diligencia_preguntas',
                'seguimientos.miembros_hogar',
                'seguimientos.registro_nucleos',
                'seguimientos.numero_nucleos',
                'seguimientos.registro_certificado',
                'seguimientos.formulario_imagenes',
                'certificados.code', // Campo de certificado
                'users.name as nombre_usuario', // Nombre del usuario
                'seguimientos.created_at', // Campo created_at de seguimientos
            ])->get();
    }

    public function headings(): array
    {
        return [
            'Fecha de Seguimiento',
            'Tipo',
            'Observación',
            'Ubicacion',
            'Objetivo',
            'Tipo de Vivienda',
            'Diligencia las Preguntas',
            'Miembros del Hogar',
            'Registro Nucleos',
            'Numero de Nucleos',
            'Registro Certificado',
            'Formulario con Imagenes',
            'Código de Certificado', // Campo de certificado
            'Nombre de Usuario', // Nombre del usuario
            'Fecha de Creación',
        ];
    }
}
